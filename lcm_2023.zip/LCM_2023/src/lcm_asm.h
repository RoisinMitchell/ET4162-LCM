/*
 * lcm_asm.h
 *
 *  Created on: 18 Apr 2023
 *      Author: ciaran.macnamee
 */

#ifndef LCM_ASM_H_
#define LCM_ASM_H_

extern long long int lcm_asm(long long int x, long long int y);

#endif /* LCM_ASM_H_ */
